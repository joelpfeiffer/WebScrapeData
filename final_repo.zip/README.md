# Fuel scraper
